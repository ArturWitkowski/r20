# r20
Zadanie 11.7
